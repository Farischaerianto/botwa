# AbilBotz ( Base )

AbilBase V1

## FOR TERMUX USER

```
> pkg update && pkg upgrade
> pkg install git -y
> pkg install nodejs -y
> pkg install ffmpeg -y
> pkg install imagemagick -y
> pkg install wget -y
> pkg install libwebp -y
> termux-setup-storage
> git clone https://github.com/AbilBotz/BaseV1
> cd BaseV1
> node main.js
```
## For Windows
```bash
git clone https://github.com/AbilBotz/BaseV1.git
cd BaseV1
npm start
```
## For VPS
```bash
apt install nodejs 
apt install git 
apt apt install ffmpeg 
apt apt install libwebp 
apt apt install imagemagick
apt install bash
git clone https://github.com/AbilBotz/BaseV1.git
cd BaseV1
npm start
```

## ```GROUP BOT```

- [`GROUP WA`](https://chat.whatsapp.com/CS4ESARec5o476nHesGIDt)


---------

## Requirements

* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://www.gyan.dev/ffmpeg/builds/) (for sticker command)
* [Libwebp](https://developers.google.com/speed/webp/download) (for sticker wm)


## ```FOLLOW ALL SOSIALMEDIA ME```
<p align="center"> 
<a href="https://wa.me/6282293295376"><img src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="https://youtube.com/channel/UCJPqI5eVhKPXPL2V8y6pIDA"><img src="https://img.shields.io/badge/YouTube ABIL BOTZ-ff0000?style=for-the-badge&logo=youtube&logoColor=ff000000&link=https://youtube.com/channel/UCJPqI5eVhKPXPL2V8y6pIDA" /><br>
</p>


## Thanks To
Narutomo,Mhankbarbar,Allah Swt,Ortugw,AbilBotz,Farrz,

