module.exports.mess = {
	        wait: '𝑾𝒂𝒊𝒕 𝑨 𝑴𝒊𝒏𝒖𝒕𝒆🍂, 𝒀𝒐𝒖𝒓 𝑹𝒆𝒒𝒖𝒆𝒔𝒕 𝑰𝒏 𝑷𝒓𝒐𝒄𝒆𝒔𝒔',
			success: '[ √ ] 𝚂𝚞𝚌𝚌𝚎𝚜𝚜...~',
			wrongFormat: 'Format salah, coba liat lagi di menu',
			error: {
				stick: 'bukan sticker itu:v',
				Iv: 'Link tidak valid',
				api: 'Ups, terjadi kesalahan',
				Ban: '*Maaf Tapi Kamu Sudah Terbanned Silahkan Minta Owner Untuk Membukanya*'
			},
			only: {
				owner: ' ```-「 OWNER BOT ONLY 」-``` ',
				admin: ' ```-「 ADMIN GROUP ONLY 」-``` ',
				prem: '```-「 PREMIUM USER ONLY 」-```, kirim perintah *!buypremium* untuk membeli premium',
				group: 'Maaf! Command ini khusus untuk di dalam Group saja.',
				Badmin: 'Maaf! Command ini khusus untuk Bot ketika jadi admin!!',
			}
		}
